# Temp Predict
WebApp.py contains the code that we used to deploy our LSTM model to gradio.

The file starting with (Used) is the jupyter notebook we used to train our model on the San Diego 2012-2017 data specifically.

